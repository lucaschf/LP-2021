#ifndef DERIVED_STRING_H
#define DERIVED_STRING_H

constexpr int SEQUENCE_LENGHT = 200;

// c string with predefined length.
typedef char CharSequence[SEQUENCE_LENGHT];

#endif // !DERIVED_STRING_H